module TypeProf
  VERSION = "0.11.0"
end
